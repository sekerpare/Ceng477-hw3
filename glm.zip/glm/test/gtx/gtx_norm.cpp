#include <glm/gtx/norm.hpp>

int main()
{
	int Error(0);

	return Error;
}
